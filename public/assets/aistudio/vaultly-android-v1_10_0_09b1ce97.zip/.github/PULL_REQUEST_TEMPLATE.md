## What does this change?

## How did you test it? (phone, Android version)

## Checklist
- [ ] No new network permission or tracking
- [ ] No keys, backups or real personal data included
- [ ] CHANGELOG.md updated
