---
name: Bug report
about: Something is not working
labels: bug
---
**What happened?**

**What did you expect?**

**Steps to reproduce**
1.
2.

**Phone and Android version**

**App version** (Settings, bottom of the page)

Please do not include real card numbers or personal data in screenshots.
